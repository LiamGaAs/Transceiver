# Connectors_HDMI.pretty
HDMI (High-Definition Multimedia Interface) connector footprints
